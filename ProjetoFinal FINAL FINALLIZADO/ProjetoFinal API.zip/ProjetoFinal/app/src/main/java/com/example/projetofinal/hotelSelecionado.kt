package com.example.projetofinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.GsonBuilder
import kotlinx.android.synthetic.main.activity_hotel_selecionado.*

class hotelSelecionado : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hotel_selecionado)

        // API moeda
        val textView = findViewById<TextView>(R.id.text)
        // Instantiate the RequestQueue.
        val queue = Volley.newRequestQueue(this)
        val url = "https://economia,awesomeapi.com.br/json/USD-BRL"

        // Request a string response from the provided URL.
        val stringRequest = StringRequest(
            Request.Method.GET, url,
            Response.Listener<String> { response ->

                val gson = GsonBuilder().create()

                val result = gson.fromJson(response.toString(),Array<Moeda>::class.java).toList()

                tvNomeMoeda.text = result.firstOrNull()?.name,toString()
                tvCotacaoMoeda.text = result.firstOrNull()?.high.toString()
            },
            Response.ErrorListener { textView.text = "Ta funcionando não" } )

        // Add the request to the RequestQueue.
        queue.add(stringRequest)

        // -------- FIM API MOEDA -------------------

        var idHotel = intent.getStringExtra("idHotel")

            if(idHotel.toString() == "Espaço Bambu Eventos"){
            fotoHotel.setImageResource(R.drawable.bambu)
                nomeHotel.text = idHotel.toString()
                listaDiaria.text = "R$: 345,00"
                listaCritica.text ="4.5/5"
                listaTelefone.text = "(61) 99972-5595"
                endHotel.text = "SMLN MI 3 Conjunto 4 Casa 31 - Lago Norte, Brasília - DF"


            } else if(idHotel.toString() == "Chalés Bela Vista"){
                fotoHotel.setImageResource(R.drawable.belavista)
                nomeHotel.text = idHotel.toString()
                listaDiaria.text = "R$: 120,00"
                listaCritica.text ="4.8/5"
                listaTelefone.text = "(62) 98293-8919"
                endHotel.text = "Rua Brasília Quadra A Lote 2, Pirenópolis - GO"

            } else if(idHotel.toString() == "Fazenda Bem Ecológico"){
                fotoHotel.setImageResource(R.drawable.bemecologico)
                nomeHotel.text = idHotel.toString()
                listaDiaria.text = "R$: 540,00"
                listaCritica.text ="5/5"
                listaTelefone.text = "(61) 99997-0314"
                endHotel.text = "DF 205 KM 44,5, Núcleo Rural Monjolo - Planaltina, Brasília - DF"

            } else if(idHotel.toString() == "Condomínio Lake Side"){
                fotoHotel.setImageResource(R.drawable.lakeside)
                nomeHotel.text = idHotel.toString()
                listaDiaria.text = "R$: 198,00"
                listaCritica.text ="4.5/5"
                listaTelefone.text = "(61) 3251-5109"
                endHotel.text = "SHTN Trecho 1 Conjunto 2 - Asa Norte, Brasília - DF"

            } else if(idHotel.toString() == "Cullinan Hplus Premium"){
                fotoHotel.setImageResource(R.drawable.cullivan)
                nomeHotel.text = idHotel.toString()
                listaDiaria.text = "R$: 223,00"
                listaCritica.text ="4.6/5"
                listaTelefone.text = "(61) 3426-5000"
                endHotel.text = "SHN Q. 4 - Brasília, DF"

            }

        btnRetornar.setOnClickListener{
            Intent(this, listaHoteis::class.java).also { startActivity(it) }
        }

    }
}