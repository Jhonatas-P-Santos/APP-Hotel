package com.example.projetofinal;

public class Moeda {
    var name:String = ""
    var high:Double = 0.0
}
